package com.securebrowser.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.security.MessageDigest

class MainActivity : Activity() {
    private data class BrowserTab(val id: Int, val webView: WebView)

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabId = 0
    private var nextTabId = 1
    private lateinit var root: LinearLayout
    private lateinit var tabStrip: LinearLayout
    private lateinit var pageContainer: LinearLayout
    private lateinit var addressBar: EditText
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("secure_browser", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        buildInterface()
        createTab(prefs.getString("homepage", "https://www.google.com")!!)
        if (!prefs.contains("pin_hash")) showCreatePinDialog()
    }

    private fun buildInterface() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17, 24, 39))
        }

        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        root.addView(tabStrip, LinearLayout.LayoutParams(-1, dp(48)))

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(6), dp(6))
        }
        toolbar.addView(toolButton("‹") { currentWebView()?.goBack() })
        toolbar.addView(toolButton("›") { currentWebView()?.goForward() })
        toolbar.addView(toolButton("↻") { currentWebView()?.reload() })

        addressBar = EditText(this).apply {
            hint = "Search or enter address"
            setSingleLine(true)
            setTextColor(Color.BLACK)
            setHintTextColor(Color.DKGRAY)
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), 0, dp(12), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, event ->
                val go = action == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                    event?.keyCode == KeyEvent.KEYCODE_ENTER
                if (go) navigate(addressBar.text.toString())
                go
            }
        }
        toolbar.addView(addressBar, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        toolbar.addView(toolButton("Go") { navigate(addressBar.text.toString()) })
        toolbar.addView(toolButton("⚙") { unlockSettings() })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(50)))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))

        pageContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(pageContainer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun createTab(url: String = prefs.getString("homepage", "https://www.google.com")!!) {
        val id = nextTabId++
        val webView = WebView(this)
        configure(webView, id)
        tabs.add(BrowserTab(id, webView))
        activeTabId = id
        showActiveTab()
        webView.loadUrl(url)
    }

    private fun configure(webView: WebView, tabId: Int) {
        webView.settings.apply {
            javaScriptEnabled = prefs.getBoolean("javascript", true)
            domStorageEnabled = true
            databaseEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(false)
            userAgentString = userAgentString + " SecureBrowser/1.0"
        }
        CookieManager.getInstance().setAcceptCookie(prefs.getBoolean("cookies", true))
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            override fun onPageFinished(view: WebView, url: String) {
                if (tabId == activeTabId) addressBar.setText(url)
                refreshTabs()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (tabId != activeTabId) return
                progress.progress = newProgress
                progress.visibility = if (newProgress in 0..99) View.VISIBLE else View.GONE
            }
            override fun onReceivedTitle(view: WebView, title: String?) { refreshTabs() }
        }
    }

    private fun showActiveTab() {
        pageContainer.removeAllViews()
        val tab = tabs.firstOrNull { it.id == activeTabId } ?: return
        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
        pageContainer.addView(tab.webView, LinearLayout.LayoutParams(-1, -1))
        addressBar.setText(tab.webView.url.orEmpty())
        refreshTabs()
    }

    private fun refreshTabs() {
        tabStrip.removeAllViews()
        tabs.forEachIndexed { index, tab ->
            val title = tab.webView.title?.take(14)?.ifBlank { null } ?: "Tab ${index + 1}"
            val button = Button(this).apply {
                text = if (tab.id == activeTabId) "● $title  ×" else "$title  ×"
                isAllCaps = false
                setOnClickListener { activeTabId = tab.id; showActiveTab() }
                setOnLongClickListener { closeTab(tab.id); true }
            }
            tabStrip.addView(button, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        tabStrip.addView(Button(this).apply {
            text = "+"
            textSize = 20f
            setOnClickListener { createTab() }
        }, LinearLayout.LayoutParams(dp(48), dp(40)))
    }

    private fun closeTab(id: Int) {
        if (tabs.size == 1) {
            currentWebView()?.loadUrl(prefs.getString("homepage", "https://www.google.com")!!)
            return
        }
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val removed = tabs.removeAt(index)
        removed.webView.destroy()
        if (activeTabId == id) activeTabId = tabs.getOrNull(index)?.id ?: tabs.last().id
        showActiveTab()
    }

    private fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = when {
            input.startsWith("http://", true) || input.startsWith("https://", true) -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}" 
        }
        currentWebView()?.loadUrl(url)
        addressBar.clearFocus()
    }

    private fun unlockSettings() {
        val entry = pinEntry("Enter settings PIN")
        AlertDialog.Builder(this).setTitle("Locked settings").setView(entry)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Unlock") { _, _ ->
                if (hash(entry.text.toString()) == prefs.getString("pin_hash", "")) showSettings()
                else Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showCreatePinDialog() {
        val entry = pinEntry("Create a 4–8 digit PIN")
        val dialog = AlertDialog.Builder(this).setTitle("Protect settings").setMessage(
            "Create the PIN required to change browser settings."
        ).setView(entry).setCancelable(false).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = entry.text.toString()
                if (!pin.matches(Regex("\\d{4,8}"))) {
                    entry.error = "Use 4–8 numbers"
                } else {
                    prefs.edit().putString("pin_hash", hash(pin)).apply()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun showSettings() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        layout.addView(TextView(this).apply { text = "Homepage" })
        val homepage = EditText(this).apply {
            setText(prefs.getString("homepage", "https://www.google.com")); setSingleLine(true)
        }
        val js = CheckBox(this).apply { text = "Allow JavaScript"; isChecked = prefs.getBoolean("javascript", true) }
        val cookies = CheckBox(this).apply { text = "Allow cookies"; isChecked = prefs.getBoolean("cookies", true) }
        layout.addView(homepage); layout.addView(js); layout.addView(cookies)
        layout.addView(Button(this).apply {
            text = "Clear browsing data"
            setOnClickListener {
                tabs.forEach { it.webView.clearHistory(); it.webView.clearCache(true) }
                CookieManager.getInstance().removeAllCookies(null)
                Toast.makeText(this@MainActivity, "Browsing data cleared", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "Change PIN"
            setOnClickListener { showCreatePinDialog() }
        })
        AlertDialog.Builder(this).setTitle("Settings").setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("homepage", normalizeHomepage(homepage.text.toString()))
                    .putBoolean("javascript", js.isChecked).putBoolean("cookies", cookies.isChecked).apply()
                tabs.forEach { it.webView.settings.javaScriptEnabled = js.isChecked }
                CookieManager.getInstance().setAcceptCookie(cookies.isChecked)
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun normalizeHomepage(value: String): String {
        val text = value.trim()
        return if (text.startsWith("http://") || text.startsWith("https://")) text else "https://$text"
    }

    private fun pinEntry(hintText: String) = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        setPadding(dp(24), dp(12), dp(24), dp(12))
    }

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(("secure-browser-local-salt:$value").toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun currentWebView() = tabs.firstOrNull { it.id == activeTabId }?.webView

    private fun toolButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { action() }
    }.also { it.layoutParams = LinearLayout.LayoutParams(dp(48), dp(42)) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (currentWebView()?.canGoBack() == true) currentWebView()?.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.webView.destroy() }
        super.onDestroy()
    }
}
