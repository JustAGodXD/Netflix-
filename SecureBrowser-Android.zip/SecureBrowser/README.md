# AnimeGo for Android

A native Android browser prototype with:

- Screenshot and screen-recording blocking via Android `FLAG_SECURE`
- AnimeGo username/password gate before browser content is created or shown
- Full-screen anime-inspired neon login and account-creation experience
- Multiple tabs (tap a tab to select it, long-press it to close it)
- Address bar with URL navigation and Google search
- Back, forward, reload, and Go controls
- PIN-protected settings
- Homepage, JavaScript, cookies, and clear-browsing-data settings

## Open and build

1. Install the latest stable Android Studio.
2. Choose **Open** and select this `SecureBrowser` folder.
3. Let Android Studio install the requested Android SDK and sync Gradle.
4. Connect an Android phone with USB debugging enabled, or create an emulator.
5. Press **Run**.

To create an installable APK, use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
The APK will be created under `app/build/outputs/apk/`.

## Build entirely from a phone with GitHub

This project includes `.github/workflows/build-apk.yml`. After the extracted
contents of `SecureBrowser` are uploaded to the root of a GitHub repository,
GitHub Actions automatically builds the APK. Open the repository's **Actions**
tab, select **Build Android APK**, and download the **SecureBrowser-APK**
artifact after the green check appears.

## Important limitations

`FLAG_SECURE` blocks ordinary Android screenshots, recent-app previews, and most
screen recording/casting paths. No app can prevent somebody from photographing
the display with another camera. Rooted or modified Android systems may also
bypass operating-system protections.

This first version uses Android WebView. It is suitable as a working prototype,
but it should receive additional security review, certificate-error handling,
download handling, file-picker support, accessibility work, and device testing
before public release.
