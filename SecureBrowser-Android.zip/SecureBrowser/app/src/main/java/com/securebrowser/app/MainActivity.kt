package com.securebrowser.app

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.net.URLEncoder
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class MainActivity : Activity() {
    private data class BrowserTab(val id: Int, val webView: WebView)

    private val tabs = mutableListOf<BrowserTab>()
    private var activeTabId = 0
    private var nextTabId = 1
    private lateinit var root: LinearLayout
    private lateinit var tabStrip: LinearLayout
    private lateinit var pageContainer: LinearLayout
    private lateinit var addressBar: EditText
    private lateinit var progress: ProgressBar
    private val prefs by lazy { getSharedPreferences("secure_browser", MODE_PRIVATE) }
    private var authenticated = false
    private var contentBuilt = false
    private var loginDialogShowing = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        showLockedBackground()
        if (prefs.contains("login_username")) showLoginDialog() else showCreateAccountDialog()
    }

    override fun onStart() {
        super.onStart()
        if (!authenticated && prefs.contains("login_username") && !loginDialogShowing) {
            showLoginDialog()
        }
    }

    override fun onStop() {
        if (!isChangingConfigurations) {
            authenticated = false
            if (contentBuilt) root.visibility = View.INVISIBLE
        }
        super.onStop()
    }

    private fun showLockedBackground() {
        setContentView(AuthBackdrop(this))
    }

    private fun openBrowser() {
        authenticated = true
        loginDialogShowing = false
        if (!contentBuilt) {
            buildInterface()
            createTab(prefs.getString("homepage", "https://www.google.com")!!)
            contentBuilt = true
            if (!prefs.contains("pin_hash")) showCreatePinDialog()
        } else {
            root.visibility = View.VISIBLE
            setContentView(root)
        }
    }

    private fun showCreateAccountDialog() {
        showAuthScreen(createAccount = true)
    }

    private fun showLoginDialog() {
        showAuthScreen(createAccount = false)
    }

    private fun showAuthScreen(createAccount: Boolean) {
        loginDialogShowing = true
        if (contentBuilt) root.visibility = View.INVISIBLE

        val frame = FrameLayout(this)
        frame.addView(AuthBackdrop(this), FrameLayout.LayoutParams(-1, -1))
        val scroll = ScrollView(this).apply { isFillViewport = true }
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(22), dp(28), dp(22), dp(28))
        }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(26), dp(28), dp(26), dp(26))
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(Color.argb(235, 17, 19, 44))
                setStroke(dp(2), Color.rgb(244, 114, 182))
            }
            elevation = dp(18).toFloat()
        }
        card.addView(TextView(this).apply {
            text = "✦  ANIMEGO  ✦"
            textSize = 34f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = .08f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(103, 232, 249))
        })
        card.addView(TextView(this).apply {
            text = if (createAccount) "CREATE YOUR HERO PROFILE" else "WELCOME BACK, HERO"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            letterSpacing = .12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(244, 114, 182))
            setPadding(0, dp(8), 0, dp(4))
        })
        card.addView(TextView(this).apply {
            text = "Your next adventure starts here."
            textSize = 15f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(203, 213, 225))
            setPadding(0, 0, 0, dp(20))
        })

        val username = authField("Username", false)
        val password = authField("Password", true)
        val confirmation = if (createAccount) authField("Confirm password", true) else null
        card.addView(username, fieldParams())
        card.addView(password, fieldParams())
        confirmation?.let { card.addView(it, fieldParams()) }

        val error = TextView(this).apply {
            setTextColor(Color.rgb(251, 113, 133))
            textSize = 13f
            gravity = Gravity.CENTER
            visibility = View.GONE
            setPadding(0, dp(4), 0, dp(4))
        }
        card.addView(error)
        val action = Button(this).apply {
            text = if (createAccount) "BEGIN ADVENTURE  ➜" else "ENTER ANIMEGO  ➜"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            isAllCaps = false
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Color.rgb(124, 58, 237), Color.rgb(236, 72, 153), Color.rgb(6, 182, 212))
            ).apply { cornerRadius = dp(16).toFloat() }
            elevation = dp(8).toFloat()
            setOnClickListener {
                error.visibility = View.GONE
                val name = username.text.toString().trim()
                val pass = password.text.toString()
                if (createAccount) {
                    when {
                        name.length < 3 -> showAuthError(error, "Username needs at least 3 characters")
                        pass.length < 6 -> showAuthError(error, "Password needs at least 6 characters")
                        pass != confirmation?.text.toString() -> showAuthError(error, "Passwords do not match")
                        else -> {
                            val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
                            prefs.edit()
                                .putString("login_username", name)
                                .putString("login_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
                                .putString("login_password", passwordHash(pass, salt))
                                .apply()
                            openBrowser()
                        }
                    }
                } else {
                    val saltText = prefs.getString("login_salt", "").orEmpty()
                    val salt = runCatching { Base64.decode(saltText, Base64.NO_WRAP) }.getOrDefault(ByteArray(0))
                    val valid = name == prefs.getString("login_username", "") && salt.isNotEmpty() &&
                        passwordHash(pass, salt) == prefs.getString("login_password", "")
                    if (valid) {
                        openBrowser()
                    } else {
                        password.text.clear()
                        showAuthError(error, "Incorrect username or password")
                    }
                }
            }
        }
        card.addView(action, LinearLayout.LayoutParams(-1, dp(54)).apply { topMargin = dp(12) })
        if (!createAccount) card.addView(TextView(this).apply {
            text = "Close AnimeGo"
            textSize = 13f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(148, 163, 184))
            setPadding(0, dp(18), 0, 0)
            setOnClickListener { finish() }
        })
        card.addView(TextView(this).apply {
            text = "★  DISCOVER  •  WATCH  •  EXPLORE  ★"
            textSize = 11f
            letterSpacing = .08f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(103, 232, 249))
            setPadding(0, dp(20), 0, 0)
        })
        outer.addView(card, LinearLayout.LayoutParams(-1, -2))
        scroll.addView(outer, FrameLayout.LayoutParams(-1, -1))
        frame.addView(scroll, FrameLayout.LayoutParams(-1, -1))
        setContentView(frame)
    }

    private fun authField(label: String, password: Boolean) = EditText(this).apply {
        hint = label
        setSingleLine(true)
        textSize = 16f
        setTextColor(Color.WHITE)
        setHintTextColor(Color.rgb(148, 163, 184))
        setPadding(dp(18), 0, dp(18), 0)
        inputType = InputType.TYPE_CLASS_TEXT or if (password) {
            InputType.TYPE_TEXT_VARIATION_PASSWORD
        } else {
            InputType.TYPE_TEXT_VARIATION_NORMAL
        }
        background = GradientDrawable().apply {
            cornerRadius = dp(14).toFloat()
            setColor(Color.argb(210, 30, 41, 72))
            setStroke(dp(1), Color.rgb(99, 102, 241))
        }
    }

    private fun fieldParams() = LinearLayout.LayoutParams(-1, dp(56)).apply {
        bottomMargin = dp(12)
    }

    private fun showAuthError(view: TextView, message: String) {
        view.text = message
        view.visibility = View.VISIBLE
    }

    private inner class AuthBackdrop(context: android.content.Context) : View(context) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            paint.shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(Color.rgb(8, 10, 32), Color.rgb(49, 18, 86), Color.rgb(5, 51, 78)),
                null, Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
            paint.shader = null
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = dp(4).toFloat()
            paint.color = Color.argb(115, 244, 114, 182)
            canvas.drawCircle(width * .88f, height * .14f, width * .25f, paint)
            paint.strokeWidth = dp(2).toFloat()
            paint.color = Color.argb(110, 103, 232, 249)
            canvas.drawCircle(width * .10f, height * .84f, width * .32f, paint)
            paint.style = Paint.Style.FILL
            paint.color = Color.argb(170, 255, 255, 255)
            val stars = arrayOf(.10f to .14f, .22f to .08f, .82f to .34f, .91f to .72f, .17f to .66f, .72f to .90f)
            stars.forEach { (x, y) -> canvas.drawCircle(width * x, height * y, dp(2).toFloat(), paint) }
            paint.color = Color.argb(45, 255, 255, 255)
            paint.strokeWidth = dp(1).toFloat()
            repeat(8) { i ->
                val y = height * (.1f + i * .12f)
                canvas.drawLine(0f, y, width * .35f, y - width * .18f, paint)
                canvas.drawLine(width.toFloat(), y, width * .65f, y + width * .18f, paint)
            }
        }
    }

    private fun passwordHash(password: String, salt: ByteArray): String {
        val spec = PBEKeySpec(password.toCharArray(), salt, 120_000, 256)
        return try {
            Base64.encodeToString(
                SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded,
                Base64.NO_WRAP
            )
        } finally {
            spec.clearPassword()
        }
    }

    private fun buildInterface() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(17, 24, 39))
        }

        tabStrip = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(5), dp(6), dp(5))
        }
        root.addView(tabStrip, LinearLayout.LayoutParams(-1, dp(48)))

        val toolbar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), 0, dp(6), dp(6))
        }
        toolbar.addView(toolButton("‹") { currentWebView()?.goBack() })
        toolbar.addView(toolButton("›") { currentWebView()?.goForward() })
        toolbar.addView(toolButton("↻") { currentWebView()?.reload() })

        addressBar = EditText(this).apply {
            hint = "Search or enter address"
            setSingleLine(true)
            setTextColor(Color.BLACK)
            setHintTextColor(Color.DKGRAY)
            setBackgroundColor(Color.WHITE)
            setPadding(dp(12), 0, dp(12), 0)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            imeOptions = android.view.inputmethod.EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, event ->
                val go = action == android.view.inputmethod.EditorInfo.IME_ACTION_GO ||
                    event?.keyCode == KeyEvent.KEYCODE_ENTER
                if (go) navigate(addressBar.text.toString())
                go
            }
        }
        toolbar.addView(addressBar, LinearLayout.LayoutParams(0, dp(42), 1f).apply {
            marginStart = dp(4); marginEnd = dp(4)
        })
        toolbar.addView(toolButton("Go") { navigate(addressBar.text.toString()) })
        toolbar.addView(toolButton("⚙") { unlockSettings() })
        root.addView(toolbar, LinearLayout.LayoutParams(-1, dp(50)))

        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            visibility = View.GONE
        }
        root.addView(progress, LinearLayout.LayoutParams(-1, dp(3)))

        pageContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(pageContainer, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun createTab(url: String = prefs.getString("homepage", "https://www.google.com")!!) {
        val id = nextTabId++
        val webView = WebView(this)
        configure(webView, id)
        tabs.add(BrowserTab(id, webView))
        activeTabId = id
        showActiveTab()
        webView.loadUrl(url)
    }

    private fun configure(webView: WebView, tabId: Int) {
        webView.settings.apply {
            javaScriptEnabled = prefs.getBoolean("javascript", true)
            domStorageEnabled = true
            databaseEnabled = true
            builtInZoomControls = true
            displayZoomControls = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(false)
            userAgentString = userAgentString + " SecureBrowser/1.0"
        }
        CookieManager.getInstance().setAcceptCookie(prefs.getBoolean("cookies", true))
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean = false
            override fun onPageFinished(view: WebView, url: String) {
                if (tabId == activeTabId) addressBar.setText(url)
                refreshTabs()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (tabId != activeTabId) return
                progress.progress = newProgress
                progress.visibility = if (newProgress in 0..99) View.VISIBLE else View.GONE
            }
            override fun onReceivedTitle(view: WebView, title: String?) { refreshTabs() }
        }
    }

    private fun showActiveTab() {
        pageContainer.removeAllViews()
        val tab = tabs.firstOrNull { it.id == activeTabId } ?: return
        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
        pageContainer.addView(tab.webView, LinearLayout.LayoutParams(-1, -1))
        addressBar.setText(tab.webView.url.orEmpty())
        refreshTabs()
    }

    private fun refreshTabs() {
        tabStrip.removeAllViews()
        tabs.forEachIndexed { index, tab ->
            val title = tab.webView.title?.take(14)?.ifBlank { null } ?: "Tab ${index + 1}"
            val button = Button(this).apply {
                text = if (tab.id == activeTabId) "● $title  ×" else "$title  ×"
                isAllCaps = false
                setOnClickListener { activeTabId = tab.id; showActiveTab() }
                setOnLongClickListener { closeTab(tab.id); true }
            }
            tabStrip.addView(button, LinearLayout.LayoutParams(0, dp(40), 1f))
        }
        tabStrip.addView(Button(this).apply {
            text = "+"
            textSize = 20f
            setOnClickListener { createTab() }
        }, LinearLayout.LayoutParams(dp(48), dp(40)))
    }

    private fun closeTab(id: Int) {
        if (tabs.size == 1) {
            currentWebView()?.loadUrl(prefs.getString("homepage", "https://www.google.com")!!)
            return
        }
        val index = tabs.indexOfFirst { it.id == id }
        if (index < 0) return
        val removed = tabs.removeAt(index)
        removed.webView.destroy()
        if (activeTabId == id) activeTabId = tabs.getOrNull(index)?.id ?: tabs.last().id
        showActiveTab()
    }

    private fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isBlank()) return
        val url = when {
            input.startsWith("http://", true) || input.startsWith("https://", true) -> input
            input.contains(".") && !input.contains(" ") -> "https://$input"
            else -> "https://www.google.com/search?q=${URLEncoder.encode(input, "UTF-8")}" 
        }
        currentWebView()?.loadUrl(url)
        addressBar.clearFocus()
    }

    private fun unlockSettings() {
        val entry = pinEntry("Enter settings PIN")
        AlertDialog.Builder(this).setTitle("Locked settings").setView(entry)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Unlock") { _, _ ->
                if (hash(entry.text.toString()) == prefs.getString("pin_hash", "")) showSettings()
                else Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun showCreatePinDialog() {
        val entry = pinEntry("Create a 4–8 digit PIN")
        val dialog = AlertDialog.Builder(this).setTitle("Protect settings").setMessage(
            "Create the PIN required to change browser settings."
        ).setView(entry).setCancelable(false).setPositiveButton("Save", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val pin = entry.text.toString()
                if (!pin.matches(Regex("\\d{4,8}"))) {
                    entry.error = "Use 4–8 numbers"
                } else {
                    prefs.edit().putString("pin_hash", hash(pin)).apply()
                    dialog.dismiss()
                }
            }
        }
        dialog.show()
    }

    private fun showSettings() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
        }
        layout.addView(TextView(this).apply { text = "Homepage" })
        val homepage = EditText(this).apply {
            setText(prefs.getString("homepage", "https://www.google.com")); setSingleLine(true)
        }
        val js = CheckBox(this).apply { text = "Allow JavaScript"; isChecked = prefs.getBoolean("javascript", true) }
        val cookies = CheckBox(this).apply { text = "Allow cookies"; isChecked = prefs.getBoolean("cookies", true) }
        layout.addView(homepage); layout.addView(js); layout.addView(cookies)
        layout.addView(Button(this).apply {
            text = "Clear browsing data"
            setOnClickListener {
                tabs.forEach { it.webView.clearHistory(); it.webView.clearCache(true) }
                CookieManager.getInstance().removeAllCookies(null)
                Toast.makeText(this@MainActivity, "Browsing data cleared", Toast.LENGTH_SHORT).show()
            }
        })
        layout.addView(Button(this).apply {
            text = "Change PIN"
            setOnClickListener { showCreatePinDialog() }
        })
        AlertDialog.Builder(this).setTitle("Settings").setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("homepage", normalizeHomepage(homepage.text.toString()))
                    .putBoolean("javascript", js.isChecked).putBoolean("cookies", cookies.isChecked).apply()
                tabs.forEach { it.webView.settings.javaScriptEnabled = js.isChecked }
                CookieManager.getInstance().setAcceptCookie(cookies.isChecked)
                Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show()
            }.show()
    }

    private fun normalizeHomepage(value: String): String {
        val text = value.trim()
        return if (text.startsWith("http://") || text.startsWith("https://")) text else "https://$text"
    }

    private fun pinEntry(hintText: String) = EditText(this).apply {
        hint = hintText
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        setPadding(dp(24), dp(12), dp(24), dp(12))
    }

    private fun hash(value: String): String = MessageDigest.getInstance("SHA-256")
        .digest(("secure-browser-local-salt:$value").toByteArray())
        .joinToString("") { "%02x".format(it) }

    private fun currentWebView() = tabs.firstOrNull { it.id == activeTabId }?.webView

    private fun toolButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        minWidth = 0
        minimumWidth = 0
        setPadding(dp(8), 0, dp(8), 0)
        setOnClickListener { action() }
    }.also { it.layoutParams = LinearLayout.LayoutParams(dp(48), dp(42)) }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (currentWebView()?.canGoBack() == true) currentWebView()?.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        tabs.forEach { it.webView.destroy() }
        super.onDestroy()
    }
}
